<?php
header('Location: apps'); /* Redirect browser */

/* Make sure that code below does not get executed when we redirect. */
exit;
?>