<?php 
 $link = mysqli_connect('', 'root', '', 'absensi'); 
$db_server = ''; 
$db_name = 'absensi'; 
$db_user = 'root'; 
$db_password = ''; 
?>
